/**
 *
 * @author Akash Rajendra Ventekar
 * Class: CS-590
 * Date: 7/17/2016
 * C program to simulate command line processor capable of running other programs.  
 */

// Header files
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main(){
	//Declaration part
	char *argv[30];			// av0018@dakota:~/unix/assign2$ getconf ARG_MAX -> 2097152 This is the max arguments, but for the program just assigning 30 as the max arguments
	pid_t child_pid, pid;		// To check if the fork and wait was successful  
	int i = 0, j, k, status, argc;	// Iterator variables, exit status of child and number of arguments
	char command[409];		// Command variable
	
	printf("CS590-sh> ");		// Requirement 1: Display the promt of the shell 
	scanf("%[^\n]s", command);	// Requirement 2: Get the first input
	getchar();			// Get the \n and ignore
	fflush(stdin);
   	while(strcmp(command, "exit") != 0)	// Requirement 4: Check if the command is exit
	{
		argv[0] = strtok(command, " ");	// Requirment 3.1 Parse: Retrieve the first argument from command delimited using " "
		i = 0;				// initialize iterator to 0 before every run
		argc = 0;			// initialize the number of arguments to 0 before every run
		i++;
   		while((argv[i] = strtok(NULL, " ")) != NULL)		// Retrieve the rest of the arguments
		{		
			for(j = 0 ; j < strlen(argv[i]) ; j++)		// Shift the characters if they include quotes. If this is not added then, grep "scanf" mysh.c does not work
				if(argv[i][j] == '\"')
					for(k = j ; k < strlen(argv[i]) ; k++)
						argv[i][k] = argv[i][k + 1];
			i++;
		}
		argc = i;	// Number of arguments
		// Requirement 3.2: Fork a child process
  		child_pid = fork();

		/* Check for child process */
		if (child_pid == 0)
		{
    			if(execvp(argv[0], argv) == -1)		// Requirement 3.3: Execute the command	
    			{
				printf("bash: %s: command not found\n",argv[0]);		// If execvp fails
				exit(1);
			}
			for(j = 0 ; j < argc ; j++)
				memset(&argv[0], 0, sizeof(argv));;		// Clear the array
			exit(0);				// Return the status of the child
 		}
		else if (child_pid > 0)
		{
    		/* PARENT */
    			if((pid = wait(&status)) < 0)		// Wait on the child
			{		
      				perror("wait");
				exit(1);
      			}
			for(j = 0 ; j < argc ; j++)
                                memset(&argv[0], 0, sizeof(argv));         // Clear the array

  		}
		else
		{
    			perror("fork failed");			// If fork fails
    			_exit(1);
  		}
		memset(command, 0, sizeof(command));		//Clear the input array
		printf("CS590-sh> ");		// Requirement 1: Display the promt of the shell
                scanf("%[^\n]s", command);	// Requirement 2: Get the first input
		getchar();			// Get the \n and ignore
	}
  	exit(0); //return success
}
