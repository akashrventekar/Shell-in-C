/**
 *
 * @author Akash Rajendra Ventekar
 * Class: CS-590
 * Date: 7/17/2016
 * C program to simulate command line processor capable of running other programs.
 */

// Header files
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main() {
	//Declaration part
        pid_t child_pid, pid;           // To check if the fork and wait was successful
        int status;  			// Variable to store status of child
        char command[409];              // Variable to store input

        printf("CS590-sh> ");           // Requirement 1: Display the promt of the shell
        scanf("%[^\n]s", command);      // Requirement 2: Get the first input
        getchar();                      // Get the \n and ignore
        fflush(stdin);
        while(strcmp(command, "exit") != 0)     // Requirement 4: Check if the command is exit
        {
                // Requirement 3.2: Fork a child process
                child_pid = fork();
                /* Check for child process */
                if (child_pid == 0)
                {
                        if(execl("/bin/bash", "bash", "-c", command, NULL) == -1)         // Requirement 3.1 and 3.3: Parse and execute the command
                        {
                                printf("Command not found\n");                // If execvp fails
                                exit(1);
                        }
                        exit(0);                                // Return the status of the child
                }
                else if (child_pid > 0)
                {
                /* PARENT */
                        if((pid = wait(&status)) < 0)           // Wait on the child
                        {
                                perror("wait");
				exit(1);
                        }
                }
                else
                {
                        perror("fork failed");                  // If fork fails
                        _exit(1);
                }
		memset(command, 0, sizeof(command));		//Clear the input array
                printf("CS590-sh> ");           // Requirement 1: Display the promt of the shell
                scanf("%[^\n]s", command);      // Requirement 2: Get the first input
                getchar();                      // Get the \n and ignore
        }
        exit(0); //return success
}
